from django.db import models
from django.conf import settings

# Create your models here.


class Categoria(models.Model):
	categoria=models.CharField(max_length=50)	

	def __str__(self):
		return self.categoria

class Estatus(models.Model):
	estatus=models.CharField(max_length=30)	

	def __str__(self):
		return self.estatus				


class objetos(models.Model):
	nombre=models.CharField(max_length=100)
	talla=models.CharField(max_length=100)
	categoria=models.ForeignKey(Categoria, null=True, blank=True, on_delete=models.CASCADE)
	color=models.CharField(max_length=30)
	marca=models.CharField(max_length=40)
	subido=models.DateTimeField(auto_now_add=True)
	lugar_encontrado=models.CharField(max_length=100)
	fecha_encontrado=models.CharField(max_length=10)
	lugar_entrega=models.CharField(max_length=100)
	fecha_entrega=models.CharField(max_length=10, blank=True)
	estatus=models.ForeignKey(Estatus, null=True, blank=True, on_delete=models.CASCADE)
	foto=models.ImageField(upload_to="fotos/", blank=True)
	
	def __str__(self):
		return self.nombre