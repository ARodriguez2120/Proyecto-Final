from django.apps import AppConfig


class PerdidosConfig(AppConfig):
    name = 'perdidos'
