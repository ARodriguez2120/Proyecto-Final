from django.contrib import admin
from .models import Categoria,Estatus,objetos

# Register your models here.

admin.site.register(Categoria)
admin.site.register(Estatus)
admin.site.register(objetos)
