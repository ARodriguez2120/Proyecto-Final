from django.shortcuts import render

#--------------------------------------
from django.contrib import messages 
#from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect

from django.views import generic
from .forms import FormCreate
from .models import objetos,Categoria,Estatus


# Create your views here.

class Categorias(generic.ListView):
	template_name="pantalla/categorias_admin.html"
	model=Categoria




def listado(request,id=1):
	queryset1=Categoria.objects.get(id=id)	
	queryset2=objetos.objects.all()
	contex={"obj":queryset1,"objs":queryset2}
	return render(request,"pantalla/list.html",contex)

class details(generic.DetailView):
	template_name="pantalla/detalles.html"
	model=objetos



class Create(generic.CreateView):
 	template_name="pantalla/create.html"
 	model=objetos
 	fields=["nombre","talla","categoria","color","marca","lugar_encontrado","fecha_encontrado","lugar_entrega","fecha_entrega",
 	"estatus","foto"]
 	success_url="/"

class update (generic.UpdateView):
	template_name="pantalla/update.html"
	model=objetos
	fields=["content"]
	success_url="/"


    
# def Create(request):
     
#     if request.method == 'POST':
#        form = FormCreate(request.POST, request.FILES)
#        if form.is_valid():
#           nombre = request.POST['nombre']
#           talla= request.POST['talla']
#           categoria=
#           archivo = request.FILES['archivo']
           
#           insert = objetos(titulo=titulo, texto=texto, archiv=Archivo)
#           insert.save()
           
#           return HttpResponseRedirect(reverse('index'))
#        	else:
#             messages.error(request, "Error al procesar el formulario")
#     else:
#        return HttpResponseRedirect(reverse('index'))
