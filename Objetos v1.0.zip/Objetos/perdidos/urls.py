from django.contrib import admin
from django.urls import path
from django.conf.urls import *

from perdidos import views
app_name="lost"

urlpatterns = [
	#url(r'^media/(?P<path>.*")$', 'django.views.static.serve',{"document_root":settings.MEDIA_ROOT}),
	# path('create/',views.Create.as_view(), name="create_view"),
	path('create/',views.Create.as_view(), name="create_view"),
	path('',views.Categorias.as_view(),name="categorias_view"),
	path('listado/<int:id>',views.listado,name="list_view"),
	path('details/<int:pk>',views.details.as_view(),name="details_view"),
    path('update/<int:pk>', views.update.as_view(), name="update_view"),
]