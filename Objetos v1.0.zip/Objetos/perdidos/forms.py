from django import forms
from django.forms import ModelForm, ClearableFileInput
from .models import objetos


class CustomClearableFileInput(ClearableFileInput):
    template_with_clear = '<br>  <label for="%(clear_checkbox_id)s">%(clear_checkbox_label)s</label> %(clear)s'




class FormCreate(forms.ModelForm):
 	class Meta:
 		model=objetos
 		
 		fields=["nombre",
 		"talla",
 		"categoria",
 		"color",
 		"marca",
 		"lugar_encontrado",
 		"fecha_encontrado",
 		"lugar_entrega",
 		"fecha_entrega",
 		"estatus",
 		"foto",]


 		label={
 		"nombre": "Nombre",
 		"talla": "Tamaño",
 		"categoria": "Categoria",
 		"color": "Color",
 		"marca": "Marca",
 		"lugar_encontrado": "Lugar donde se encontró",
 		"fecha_encontrado": "Fecha cuando se encontró",
 		"lugar_entrega": "Ubicación para entrega",
 		"fecha_entrega": "Fecha que se entregó",
 		"estatus": "Estatus",
 		"foto": "Foto",
 		}

 		widgets={
 		"nombre": forms.TextInput(attrs={'class':'form-control'}),
 		"talla": forms.TextInput(attrs={'class':'form-control'}),
 		"categoria": forms.Select(attrs={'class':'form-control'}),
 		"color": forms.TextInput(attrs={'class':'form-control'}),
 		"marca": forms.TextInput(attrs={'class':'form-control'}),
 		"lugar_encontrado": forms.TextInput(attrs={'class':'form-control'}),
 		"fecha_encontrado": forms.TextInput(attrs={'class':'form-control'}),
 		"lugar_entrega": forms.TextInput(attrs={'class':'form-control'}),
 		"fecha_entrega": forms.TextInput(attrs={'class':'form-control'}),
 		"estatus": forms.TextInput(attrs={'class':'form-control'}),
 		"foto": CustomClearableFileInput
 		}