from rest_framework import generics
from perdidos.api.serializers import CategoriaModelSerializer, ObjetoModelSerializer
from perdidos.models import Categoria, objetos

class ListCategoriaAPIView(generics.ListAPIView):
    serializer_class = CategoriaModelSerializer

    def get_queryset(self, *args, **kwargs):
        return Categoria.objects.all()


class ListObjetosAPIView(generics.ListAPIView):
    serializer_class = ObjetoModelSerializer

    def get_queryset(self, *args, **kwargs):
        return objetos.objects.all()        
