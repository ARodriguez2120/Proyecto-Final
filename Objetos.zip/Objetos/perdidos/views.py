from django.shortcuts import render

#--------------------------------------
from django.contrib import messages 
#from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect

from django.views import generic
from .form import FormCreate
from .models import objetos,Categoria,Estatus,Users


# Create your views here.

class Categorias(generic.ListView):
	template_name="pantalla/categorias_admin.html"
	model=Categoria




def listado(request,id=1):
	queryset1=Categoria.objects.get(id=id)	
	queryset2=objetos.objects.all()
	contex={"obj":queryset1,"objs":queryset2}
	return render(request,"pantalla/list.html",contex)

class details(generic.DetailView):
	template_name="pantalla/detalles.html"
	model=objetos



class registro(generic.CreateView):
 	template_name="pantalla/registro.html"
 	model=Users
 	fields=["usuario","password"]
 	success_url="/"


class login(generic.CreateView):
 	template_name="pantalla/login.html"
 	model=Users
 	fields=["usuario","password"]
 	success_url="index/"

# def valid(self,form):
#     self.object = form.save(commit=False)
#     self.object.set_password(self.object.password)
#     self.object.save()
#     return HttpResponseRedirect(self.get_success_url())




class Create(generic.CreateView):
 	template_name="pantalla/create.html"
 	model=objetos
 	fields=["nombre","talla","categoria","color","marca","lugar_encontrado","fecha_encontrado","lugar_entrega","estatus","foto"]
 	success_url="/index"

class update (generic.UpdateView):
	template_name="pantalla/update.html"
	model=objetos
	#fields=["nombre","talla","categoria","color","marca","lugar_encontrado","fecha_encontrado","lugar_entrega","estatus","foto"]
	form_class=FormCreate
	success_url="/index"

class delete (generic.DeleteView):
	template_name="pantalla/delete.html"
	model=objetos
	success_url="/index"
