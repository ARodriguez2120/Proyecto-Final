from django.contrib import admin
from .models import Categoria,Estatus,objetos,Users

# Register your models here.

admin.site.register(Categoria)
admin.site.register(Users)
admin.site.register(Estatus)
admin.site.register(objetos)
