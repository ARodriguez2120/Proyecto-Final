from django import forms
from .model import objetos

class CreateObjeto(forms.ModelForm):
 	class Meta:

 		model=objetos
 		
 		fields=["nombre","talla","categoria","color","marca","lugar_encontrado","fecha_encontrado","lugar_entrega","estatus","foto"]

 		

 		widgets={"nombre":forms.TextInput(attrs={'class':'form-control','placeholder':'Ingrese nombre'}),
 		{"talla":forms.TextInput(attrs={'class':'form-control','placeholder':'Ingrese nombre'}),
 		{"categoria":forms.SelectInput(attrs={'class':'form-control'}),
 		{"color":forms.TextInput(attrs={'class':'form-control','placeholder':'Ingrese nombre'}),
 		{"marca":forms.TextInput(attrs={'class':'form-control','placeholder':'Ingrese nombre'}),
 		{"lugar_encontrado":forms.TextInput(attrs={'class':'form-control','placeholder':'Ingrese nombre'}),
 		{"fecha_encontrado":forms.TextInput(attrs={'class':'form-control','placeholder':'Ingrese nombre'}),
 		{"lugar_entrega":forms.TextInput(attrs={'class':'form-control','placeholder':'Ingrese nombre'}),
 		{"estatus":forms.SelectInput(attrs={'class':'form-control'}),

 		}